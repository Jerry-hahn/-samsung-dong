let currentData = {};

document.addEventListener('DOMContentLoaded', () => {
    fetchData();
});

async function fetchData() {
    try {
        const response = await fetch('property_data.json');
        currentData = await response.json();
        
        const now = new Date();
        document.getElementById('last-update').textContent = `Last updated: ${now.toLocaleString()}`;
        
        renderDashboard();
    } catch (error) {
        console.error('Error fetching data:', error);
        document.getElementById('property-grid').innerHTML = `
            <div class="loading-state">
                <p>Failed to load data. Please run updater.py first.</p>
            </div>
        `;
    }
}

function renderDashboard() {
    const grid = document.getElementById('property-grid');
    grid.innerHTML = '';
    
    Object.keys(currentData).forEach(key => {
        const prop = currentData[key];
        const card = document.createElement('div');
        card.className = 'property-card';
        card.innerHTML = `
            <div class="card-header">
                <div>
                    <h2 class="property-title">${prop.meta.name}</h2>
                    <p class="property-location">${prop.meta.dong} | ${prop.meta.size_label}</p>
                </div>
                <div class="property-badge">${prop.meta.type}</div>
            </div>
            
            <div class="tabs">
                <button class="tab-btn active sale" onclick="switchTab('${key}', 'sale')">매매</button>
                <button class="tab-btn jeonse" onclick="switchTab('${key}', 'jeonse')">전세</button>
                <button class="tab-btn rent" onclick="switchTab('${key}', 'rent')">월세</button>
            </div>
            
            <div id="content-${key}-sale" class="tab-content active">
                ${renderStatsGrid(prop.current.sale, prop.history, 'sale')}
            </div>
            <div id="content-${key}-jeonse" class="tab-content">
                ${renderStatsGrid(prop.current.jeonse, prop.history, 'jeonse')}
            </div>
            <div id="content-${key}-rent" class="tab-content">
                ${renderStatsGrid(prop.current.rent, prop.history, 'rent')}
            </div>

            <div class="chart-container">
                <canvas id="chart-${key}"></canvas>
            </div>
        `;
        grid.appendChild(card);
        
        // Initialize chart with Sale data by default
        renderChart(key, prop, 'sale');
    });
}

function renderStatsGrid(stats, history, type) {
    if (!stats || !stats.real) return '<p>No data available</p>';
    
    // Calculate 3-month real stats from history
    let realMin = Infinity;
    let realMax = -Infinity;
    let sumAvg = 0;
    let countAvg = 0;
    
    // Use the new schema
    const realHistory = history.real_monthly || [];
    const recentHistory = realHistory.slice(-3); // Last 3 months
    
    recentHistory.forEach(h => {
        const r = h[type];
        if (r && r.min > 0) {
            if (r.min < realMin) realMin = r.min;
            if (r.max > realMax) realMax = r.max;
            sumAvg += r.avg;
            countAvg++;
        }
    });
    
    const computedReal = countAvg > 0 ? {
        min: realMin,
        max: realMax,
        avg: Math.round(sumAvg / countAvg)
    } : { min: 0, max: 0, avg: 0 };
    
    const formatPrice = (val) => {
        if (!val || val === Infinity || val === -Infinity) return '-';
        if (val >= 10000) {
            const eok = Math.floor(val / 10000);
            const man = val % 10000;
            return man > 0 ? `${eok}억 ${man.toLocaleString()}` : `${eok}억`;
        }
        return `${val.toLocaleString()}만`;
    };

    return `
        <div class="stats-container">
            <div class="stat-box">
                <div class="stat-header real">실거래가 추이 (최근 3개월)</div>
                <div class="stat-grid">
                    <div class="stat-item">
                        <span class="stat-label">최소</span>
                        <span class="stat-value">${formatPrice(computedReal.min)}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">평균</span>
                        <span class="stat-value avg">${formatPrice(computedReal.avg)}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">최대</span>
                        <span class="stat-value">${formatPrice(computedReal.max)}</span>
                    </div>
                </div>
            </div>
            <div class="stat-box hoga">
                <div class="stat-header hoga">네이버 호가 (현재)</div>
                <div class="stat-grid">
                    <div class="stat-item">
                        <span class="stat-label">최소</span>
                        <span class="stat-value">${formatPrice(stats.hoga?.min)}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">평균</span>
                        <span class="stat-value avg">${formatPrice(stats.hoga?.avg)}</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">최대</span>
                        <span class="stat-value">${formatPrice(stats.hoga?.max)}</span>
                    </div>
                </div>
            </div>
        </div>
    `;
}

// Store chart instances to update them later
const chartInstances = {};

function switchTab(propertyId, type) {
    // Update active button
    const card = document.querySelector(`#content-${propertyId}-${type}`).closest('.property-card');
    card.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    card.querySelector(`.tab-btn.${type}`).classList.add('active');
    
    // Update active content
    card.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    document.getElementById(`content-${propertyId}-${type}`).classList.add('active');
    
    // Update chart
    renderChart(propertyId, currentData[propertyId], type);
}

function parseMonthToDate(monthStr) {
    // Input format "2023-05" -> Output Date at 15th of the month
    const parts = monthStr.split('-');
    return new Date(parseInt(parts[0]), parseInt(parts[1]) - 1, 15);
}

function renderChart(propertyId, propData, type) {
    const ctx = document.getElementById(`chart-${propertyId}`).getContext('2d');
    
    if (chartInstances[propertyId]) {
        chartInstances[propertyId].destroy();
    }
    
    const colorMap = {
        'sale': { main: '#38bdf8', bg: 'rgba(56, 189, 248, 0.1)' },
        'jeonse': { main: '#a78bfa', bg: 'rgba(167, 139, 250, 0.1)' },
        'rent': { main: '#f472b6', bg: 'rgba(244, 114, 182, 0.1)' }
    };
    const colors = colorMap[type];
    
    const realMonthly = propData.history.real_monthly || [];
    const hogaDaily = propData.history.hoga_daily || [];
    
    // Prepare time-series data
    const realAvgData = realMonthly.map(h => ({ x: parseMonthToDate(h.month), y: h[type]?.avg || null }));
    const realMinData = realMonthly.map(h => ({ x: parseMonthToDate(h.month), y: h[type]?.min || null }));
    const realMaxData = realMonthly.map(h => ({ x: parseMonthToDate(h.month), y: h[type]?.max || null }));

    const hogaAvgData = hogaDaily.map(h => ({ x: new Date(h.date), y: h[type]?.avg || null }));
    const hogaMinData = hogaDaily.map(h => ({ x: new Date(h.date), y: h[type]?.min || null }));
    const hogaMaxData = hogaDaily.map(h => ({ x: new Date(h.date), y: h[type]?.max || null }));

    const formatYAxis = (value) => {
        if (value >= 10000) return `${value / 10000}억`;
        return `${value}`;
    };

    chartInstances[propertyId] = new Chart(ctx, {
        type: 'line',
        data: {
            datasets: [
                // HOGA BANDS
                {
                    label: '호가 최고',
                    data: hogaMaxData,
                    borderColor: 'transparent',
                    backgroundColor: 'rgba(16, 185, 129, 0.05)',
                    pointRadius: 0,
                    fill: '+1',
                    tension: 0.1
                },
                {
                    label: '호가 최저',
                    data: hogaMinData,
                    borderColor: 'transparent',
                    backgroundColor: 'transparent',
                    pointRadius: 0,
                    tension: 0.1
                },
                {
                    label: '호가 평균',
                    data: hogaAvgData,
                    borderColor: '#10b981',
                    borderWidth: 2,
                    borderDash: [5, 5],
                    pointBackgroundColor: '#10b981',
                    pointRadius: 2,
                    tension: 0.1,
                    fill: false
                },
                // REAL BANDS
                {
                    label: '실거래 최고',
                    data: realMaxData,
                    borderColor: 'transparent',
                    backgroundColor: colors.bg,
                    pointRadius: 0,
                    fill: '+1',
                    tension: 0.4
                },
                {
                    label: '실거래 최저',
                    data: realMinData,
                    borderColor: 'transparent',
                    backgroundColor: 'transparent',
                    pointRadius: 0,
                    tension: 0.4
                },
                {
                    label: '실거래 평균',
                    data: realAvgData,
                    borderColor: colors.main,
                    borderWidth: 3,
                    pointBackgroundColor: '#1e293b',
                    pointBorderColor: colors.main,
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    tension: 0.4,
                    fill: false
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            interaction: {
                mode: 'index',
                intersect: false,
            },
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleFont: { family: "'Outfit', sans-serif", size: 13 },
                    bodyFont: { family: "'Outfit', sans-serif", size: 12 },
                    padding: 12,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) label += ': ';
                            if (context.parsed.y !== null) {
                                label += formatYAxis(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'month',
                        tooltipFormat: 'yyyy-MM-dd'
                    },
                    grid: { display: false },
                    ticks: {
                        color: '#94a3b8',
                        font: { family: "'Outfit', sans-serif", size: 11 }
                    }
                },
                y: {
                    beginAtZero: false,
                    grid: { color: 'rgba(255, 255, 255, 0.05)' },
                    ticks: {
                        color: '#94a3b8',
                        font: { family: "'Outfit', sans-serif", size: 11 },
                        callback: function(value) {
                            return formatYAxis(value);
                        }
                    }
                }
            }
        }
    });
}
